import React from 'react';
import BarChartData from './components/BarChartData'

function App() {
  return (
    <BarChartData />
  )
}

export default App;

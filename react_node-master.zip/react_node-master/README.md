## To Run the project execute following commands in sequence

    1. npm install
    2. npm run build
    3. npm run start-server
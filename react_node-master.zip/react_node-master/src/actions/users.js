export const addUsers = (users) => {
    return {
        type: 'ADD_USERS',
        users
    };
};
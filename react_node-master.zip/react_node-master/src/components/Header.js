import React from 'react';

const Header = () => {
    return <h1 className="header">Random Users Application</h1>;
};

export default Header;